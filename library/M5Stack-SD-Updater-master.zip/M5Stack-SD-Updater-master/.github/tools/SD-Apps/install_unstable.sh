#!/bin/bash

#git submodule update --init --recursive
#cd $SDAPP_FOLDER
## pull latest code from submodules
#git submodule foreach --recursive git pull origin master
