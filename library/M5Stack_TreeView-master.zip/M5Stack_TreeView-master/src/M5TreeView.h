#ifndef _M5TREEMENU_H_
#define _M5TREEMENU_H_

#include <MenuItem.h>
#include <MenuItemNumeric.h>
#include <LovyanGFX_DentaroUI.hpp>

#define TREE_EVENT_NONE 0
#define TREE_EVENT_BACK 1
#define TREE_EVENT_NEXT 2
#define TREE_EVENT_PREV 3
#define TREE_EVENT_HOLD 4
#define TREE_EVENT_ENTER 5

class M5TreeView : public MenuItem {
public:
  M5TreeView() : MenuItem() {};

  void begin(LGFX& lcd);

  // MenuItem* update(bool force = false);
  MenuItem* update(LGFX &lcd, bool force = false);
  bool isRedraw() const { return _redraw; }
  

  enum eCmd
  { NONE
  , BACK
  , NEXT
  , PREV
  , HOLD
  , ENTER
  };
  eCmd checkInput();
  eCmd checkInputUI();//タッチイベントのための追加関数

  void setBtnID(int _btnID);
  int getBtnID();

  int pressedBtnID = -1;

protected:
  // eCmd checkUI(int btnID);
  // void setRes(M5TreeView::eCmd _res);
  eCmd checkKB(char key);
private:
  Rect16 _cursorRect;
  uint32_t _repeat;
  uint32_t _msecLast;
  uint32_t _msec = 0;
  bool _redraw;
};

#endif
