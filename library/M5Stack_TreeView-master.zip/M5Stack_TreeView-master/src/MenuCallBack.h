#ifndef _MENUCALLBACK_H_
#define _MENUCALLBACK_H_

#include <M5Stack.h>
#include <M5TreeView.h>
#include <M5ButtonDrawer.h>

class MenuItem;

// メニュー選択時のコールバック
struct MenuCallBack {
  M5ButtonDrawer btnDrawer;
  M5TreeView* treeView;
  M5TreeView::eCmd cmd;
  MenuItem* menuItem;
  virtual void operator()(MenuItem* mi) {
    menuItem = mi;
    treeView = ((M5TreeView*)(mi->topItem()));
    lcd.fillScreen(0);
    btnDrawer.setText("Back","","");
    if (setup()) {
      byte i = -1;
      do {
        cmd = treeView->checkInput();
#ifndef ARDUINO_ODROID_ESP32
        btnDrawer.draw(0 == (++i & 0x0F));
#endif
      } while (cmd != M5TreeView::eCmd::BACK && loop());
      close();
      lcd.fillScreen(MenuItem::backgroundColor);
    }
  }
  virtual bool setup() { return true; };
  virtual bool loop()  { return false; };
  virtual void close() {};
  virtual ~MenuCallBack() {};
};

#endif
