#include <MenuItemToggle.h>
#include <Rect16.h>

void MenuItemToggle::onAfterDraw(LGFX &lcd){
  drawParts(lcd, value, this == focusItem);
}

void MenuItemToggle::setValue(bool value)
{
  this->value = value;
  if (callback) callback(this);
}

void MenuItemToggle::onEnter(LGFX &lcd) {
  value = !value;
  drawParts(lcd, value, true);
}

void MenuItemToggle::drawParts(LGFX &lcd, bool mode, int flg)
{
  int w = 32;
  Rect16 r ( rect.right() - (w + 8)
           , rect.y + 2
           , w
           , rect.h - 4);
  lcd.drawRect(r.x+1, r.y, r.w-2, r.h, frameColor[0]);
  lcd.drawRect(r.x, r.y+1, r.w, r.h-2, frameColor[0]);
  r.inflate(-2);

  w = 16;
  if (mode) {
    lcd.drawRect(r.right()-w, r.y, w    , r.h, fontColor[flg]);
    lcd.fillRect(r.x        , r.y, r.w-w, r.h, backgroundColor);
  } else {
    lcd.fillRect(r.x + w, r.y, r.w-w, r.h, backgroundColor);
  }
}

