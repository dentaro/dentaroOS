#ifndef _MENUITEMWIFICLIENT_H_
#define _MENUITEMWIFICLIENT_H_

#include <WiFi.h>
#include <MenuItem.h>
#include <Rect16.h>
#include <LovyanGFX_DentaroUI.hpp>

class MenuItemWiFiClient : public MenuItem {
public:
  MenuItemWiFiClient(const String& title, TCallBackEnter cb = 0)
  : MenuItem(title, cb) {};

  virtual void onEnter(LGFX &lcd);
  virtual void onExit();
  virtual void onAfterDraw(LGFX &lcd);

  virtual int getRightPadding() const { return 18; }

  String ssid;
  int8_t rssi;
  wifi_auth_mode_t auth;

private:
  void scanWiFi(LGFX &lcd);
};

#endif
